only change made: 
in rest.js: referring 'express' to my module, i.e. var express = require('./miniExpress');

running instructions:

run:
    node rest.js
browse to:
    http://localhost:3000/static/index.html
play as you will.
